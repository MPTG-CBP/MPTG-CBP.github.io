.. This file is a placeholder that is used in case RELENG_PATH does not
   identify the location of the releng repository.

.. _releng-workflow-release:

releng repository (missing)
===========================

.. toctree::
   :hidden:

   jenkins-howto
   jenkins-ui

This documentation was built without releng documentation.
If you want to see this documentation, set ``RELENG_PATH`` CMake variable to
point to the root of a checkout from the releng repository.

.. _releng-triggering-builds:

Triggering builds (missing)
---------------------------

This information is available when building the documentation
with releng, as indicated above.
