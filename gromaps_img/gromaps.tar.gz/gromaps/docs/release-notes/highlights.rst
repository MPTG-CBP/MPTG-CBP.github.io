Highlights
^^^^^^^^^^

|Gromacs| 2018 was released on INSERT DATE HERE. Patch releases may
have been made since then, please use the updated versions!  Here are
some highlights of what you can expect, along with more detail in the
links below!

As always, we've got several useful performance improvements ...  We
are extremely interested in your feedback on how well this worked on
your simulations and hardware. They are:

* Blah blah
* Other stuff

There are some new features available also:

* Cool thing
* Boring thing
* Automated citation bot
* Add your Spotify playlists to GROMACS quotes
