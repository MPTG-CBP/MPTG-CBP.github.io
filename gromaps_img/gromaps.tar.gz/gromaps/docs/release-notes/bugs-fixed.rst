Bugs fixed
^^^^^^^^^^

