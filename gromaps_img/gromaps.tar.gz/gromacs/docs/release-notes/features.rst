New and improved features
^^^^^^^^^^^^^^^^^^^^^^^^^

