Removed features
^^^^^^^^^^^^^^^^

