Performance improvements
^^^^^^^^^^^^^^^^^^^^^^^^

PME on GPU when running free energy perturbations not involving charges
""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
PME can now be run on a GPU when doing free energy perturbations
that do not involve perturbing charges.
