Performance improvements
^^^^^^^^^^^^^^^^^^^^^^^^

